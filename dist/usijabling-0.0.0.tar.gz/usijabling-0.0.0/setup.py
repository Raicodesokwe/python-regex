from setuptools import setup
setup(
    name='usijabling',
    author='ricode'
)
